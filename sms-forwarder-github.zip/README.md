# SMS Forwarder

Android-first Expo app for configuring consent-based SMS forwarding.

## Run from GitHub

This folder is standalone and does not require the original Replit monorepo.

```bash
npm install
npm start
```

Then press `a` for Android, `i` for iOS, or `w` for web.

## Native Android development build

Install Android Studio and the Android SDK first, then run:

```bash
npm install
npx expo prebuild --platform android
npm run android
```

The Android permissions declared in `app.json` are:

- `READ_SMS`
- `RECEIVE_SMS`
- `SEND_SMS`

## Important limitation

The current app includes the forwarding settings UI, local persistence, permission flow, and filtering controls. A production automatic forwarding engine still needs a native Android SMS receiver and sender implementation. The current Expo preview does not read or send real messages.

## Project structure

- `app/index.tsx` — main forwarding screen
- `app/settings.tsx` — privacy and device access settings
- `context/ForwardingContext.tsx` — local settings persistence
- `constants/colors.ts` — app theme
- `app.json` — Expo and Android configuration