/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#102A2A',
    tint: '#0D7C66',

    // Core surfaces
    background: '#F5F7F3',
    foreground: '#102A2A',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#102A2A',

    // Primary action color (buttons, links, active states)
    primary: '#0D7C66',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E4EEEA',
    secondaryForeground: '#16463E',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#E9EEEA',
    mutedForeground: '#6B7E7A',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#D9F1E8',
    accentForeground: '#0D6E5B',

    // Destructive actions (delete, error states)
    destructive: '#C44E4E',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#D8E2DE',
    input: '#C9D9D3',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
