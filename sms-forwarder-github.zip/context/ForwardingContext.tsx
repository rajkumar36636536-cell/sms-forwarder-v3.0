import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

export type FilterMode = 'all' | 'otp';

export type ForwardingActivity = {
  id: string;
  sender: string;
  preview: string;
  time: string;
  status: 'sent' | 'blocked';
};

type PersistedSettings = {
  isEnabled: boolean;
  destinationNumber: string;
  filterMode: FilterMode;
};

type ForwardingContextValue = PersistedSettings & {
  activity: ForwardingActivity[];
  isHydrated: boolean;
  setEnabled: (enabled: boolean) => void;
  setDestinationNumber: (number: string) => void;
  setFilterMode: (mode: FilterMode) => void;
};

const STORAGE_KEY = '@sms-forwarder/settings';
const defaultSettings: PersistedSettings = {
  isEnabled: false,
  destinationNumber: '',
  filterMode: 'all',
};

const ForwardingContext = createContext<ForwardingContextValue | null>(null);

export function ForwardingProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<PersistedSettings>(defaultSettings);
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (stored) {
          setSettings({ ...defaultSettings, ...JSON.parse(stored) });
        }
      })
      .catch(() => undefined)
      .finally(() => setIsHydrated(true));
  }, []);

  useEffect(() => {
    if (!isHydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(settings)).catch(() => undefined);
  }, [isHydrated, settings]);

  const value = useMemo<ForwardingContextValue>(
    () => ({
      ...settings,
      activity: [],
      isHydrated,
      setEnabled: (enabled) => setSettings((current) => ({ ...current, isEnabled: enabled })),
      setDestinationNumber: (destinationNumber) =>
        setSettings((current) => ({ ...current, destinationNumber })),
      setFilterMode: (filterMode) => setSettings((current) => ({ ...current, filterMode })),
    }),
    [isHydrated, settings],
  );

  return <ForwardingContext.Provider value={value}>{children}</ForwardingContext.Provider>;
}

export function useForwarding() {
  const context = useContext(ForwardingContext);
  if (!context) {
    throw new Error('useForwarding must be used inside ForwardingProvider');
  }
  return context;
}