import { Feather } from '@expo/vector-icons';
import React from 'react';
import { Linking, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

function SettingRow({
  icon,
  title,
  body,
  onPress,
  colors,
  last = false,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  title: string;
  body: string;
  onPress?: () => void;
  colors: ReturnType<typeof useColors>;
  last?: boolean;
}) {
  return (
    <Pressable
      accessibilityRole={onPress ? 'button' : undefined}
      onPress={onPress}
      style={({ pressed }) => [styles.settingRow, !last && { borderBottomColor: colors.border, borderBottomWidth: 1 }, { opacity: pressed ? 0.72 : 1 }]}
    >
      <View style={[styles.settingIcon, { backgroundColor: colors.muted }]}>
        <Feather name={icon} size={17} color={colors.primary} />
      </View>
      <View style={styles.settingCopy}>
        <Text style={[styles.settingTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.settingBody, { color: colors.mutedForeground }]}>{body}</Text>
      </View>
      {onPress ? <Feather name="chevron-right" size={18} color={colors.mutedForeground} /> : null}
    </Pressable>
  );
}

export default function SettingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const openDeviceSettings = () => {
    if (Platform.OS !== 'web') {
      Linking.openSettings().catch(() => undefined);
    }
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={{ paddingTop: insets.top + 14, paddingBottom: insets.bottom + 30 }} showsVerticalScrollIndicator={false}>
        <View style={styles.topBar}>
          <Pressable accessibilityRole="button" accessibilityLabel="Go back" testID="back-button" onPress={() => router.back()} hitSlop={12}>
            <Feather name="arrow-left" size={22} color={colors.foreground} />
          </Pressable>
          <Text style={[styles.topTitle, { color: colors.foreground }]}>Settings</Text>
          <View style={{ width: 22 }} />
        </View>

        <View style={styles.intro}>
          <Text style={[styles.pageTitle, { color: colors.foreground }]}>Your privacy,{"\n"}your control.</Text>
          <Text style={[styles.pageBody, { color: colors.mutedForeground }]}>
            Relay is designed to keep your messages close. These controls help you decide when and how forwarding can happen.
          </Text>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>DEVICE ACCESS</Text>
        <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <SettingRow
            icon="smartphone"
            title="Android permissions"
            body="Required to receive and send SMS automatically."
            onPress={openDeviceSettings}
            colors={colors}
          />
          <SettingRow
            icon="shield"
            title="On-device processing"
            body="Messages are handled locally before delivery."
            colors={colors}
            last
          />
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ABOUT RELAY</Text>
        <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <SettingRow icon="help-circle" title="How it works" body="Only authorized messages are routed." colors={colors} />
          <SettingRow icon="file-text" title="Privacy promise" body="No message archive. No account required." colors={colors} />
          <SettingRow icon="info" title="Version" body="Relay 1.0.0" colors={colors} last />
        </View>

        <View style={[styles.notice, { backgroundColor: colors.accent }]}>
          <Feather name="alert-circle" size={17} color={colors.accentForeground} />
          <Text style={[styles.noticeText, { color: colors.accentForeground }]}>
            Automatic background forwarding is available on Android with the required SMS permissions. The preview uses the same settings flow without reading your messages.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, marginBottom: 34 },
  topTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  intro: { paddingHorizontal: 20, marginBottom: 30 },
  pageTitle: { fontFamily: 'Inter_700Bold', fontSize: 29, lineHeight: 34, letterSpacing: -1, marginBottom: 12 },
  pageBody: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, maxWidth: 335 },
  sectionLabel: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2, marginHorizontal: 20, marginBottom: 10 },
  settingsCard: { borderWidth: 1, borderRadius: 18, marginHorizontal: 20, marginBottom: 28, overflow: 'hidden' },
  settingRow: { minHeight: 76, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 15, gap: 12 },
  settingIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  settingCopy: { flex: 1 },
  settingTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 13, marginBottom: 4 },
  settingBody: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16 },
  notice: { marginHorizontal: 20, borderRadius: 15, padding: 14, flexDirection: 'row', alignItems: 'flex-start', gap: 9 },
  noticeText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 11, lineHeight: 17 },
});