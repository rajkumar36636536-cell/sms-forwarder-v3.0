import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  PermissionsAndroid,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { FilterMode, useForwarding } from '@/context/ForwardingContext';

function IconCircle({
  name,
  size = 18,
  color,
  backgroundColor,
}: {
  name: React.ComponentProps<typeof Feather>['name'];
  size?: number;
  color: string;
  backgroundColor: string;
}) {
  return (
    <View style={[styles.iconCircle, { backgroundColor }]}>
      <Feather name={name} size={size} color={color} />
    </View>
  );
}

function SectionLabel({ children, colors }: { children: React.ReactNode; colors: ReturnType<typeof useColors> }) {
  return <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>{children}</Text>;
}

function StatusPill({
  enabled,
  colors,
}: {
  enabled: boolean;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={[styles.statusPill, { backgroundColor: enabled ? colors.accent : colors.muted }]}>
      <View style={[styles.statusDot, { backgroundColor: enabled ? colors.primary : colors.mutedForeground }]} />
      <Text style={[styles.statusPillText, { color: enabled ? colors.accentForeground : colors.mutedForeground }]}>
        {enabled ? 'ACTIVE' : 'PAUSED'}
      </Text>
    </View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { destinationNumber, filterMode, isEnabled, isHydrated, setDestinationNumber, setEnabled, setFilterMode } =
    useForwarding();
  const [isEditingNumber, setIsEditingNumber] = useState(false);
  const [smsPermissionState, setSmsPermissionState] = useState<'unknown' | 'granted' | 'denied'>('unknown');

  const requestSmsAccess = async () => {
    if (Platform.OS !== 'android') {
      Alert.alert(
        'Android device required',
        'SMS permissions are only available in the Android build. The web preview cannot access phone messages.',
      );
      return;
    }

    try {
      const permissions = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.READ_SMS,
        PermissionsAndroid.PERMISSIONS.RECEIVE_SMS,
        PermissionsAndroid.PERMISSIONS.SEND_SMS,
      ]);
      const hasPermissions = Object.values(permissions).every(
        (permission) => permission === PermissionsAndroid.RESULTS.GRANTED,
      );
      setSmsPermissionState(hasPermissions ? 'granted' : 'denied');
      if (!hasPermissions) {
        Alert.alert(
          'SMS permission needed',
          'Allow SMS access in Android settings before enabling automatic forwarding.',
        );
      }
    } catch {
      setSmsPermissionState('denied');
      Alert.alert(
        'Native Android build required',
        'Expo Go does not include this app’s custom SMS permissions. Use a native Android build to grant SMS access.',
      );
    }
  };

  const onToggle = async (value: boolean) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (value && !destinationNumber.trim()) {
      setIsEditingNumber(true);
      Alert.alert('Add a destination first', 'Enter the phone number that should receive forwarded messages.');
      return;
    }
    if (value && Platform.OS === 'android') {
      const permissions = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.READ_SMS,
        PermissionsAndroid.PERMISSIONS.RECEIVE_SMS,
        PermissionsAndroid.PERMISSIONS.SEND_SMS,
      ]);
      const hasPermissions = Object.values(permissions).every(
        (permission) => permission === PermissionsAndroid.RESULTS.GRANTED,
      );
      if (!hasPermissions) {
        Alert.alert(
          'SMS permission needed',
          'Relay cannot receive or send messages until you allow all SMS permissions in Android settings.',
        );
        return;
      }
    }
    setEnabled(value);
  };

  const onFilterChange = async (mode: FilterMode) => {
    await Haptics.selectionAsync();
    setFilterMode(mode);
  };

  if (!isHydrated) {
    return (
      <View style={[styles.loading, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={[styles.screen, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 28 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.brandLockup}>
            <View style={[styles.logo, { backgroundColor: colors.foreground }]}>
              <Feather name="corner-up-right" size={20} color={colors.accent} />
            </View>
            <View>
              <Text style={[styles.wordmark, { color: colors.foreground }]}>relay</Text>
              <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>SMS FORWARDER</Text>
            </View>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Open privacy and settings"
            testID="settings-button"
            onPress={() => router.push('/settings')}
            style={({ pressed }) => [styles.headerButton, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
          >
            <Feather name="sliders" size={18} color={colors.foreground} />
          </Pressable>
        </View>

        <View style={styles.greetingRow}>
          <View>
            <Text style={[styles.title, { color: colors.foreground }]}>Your messages,</Text>
            <Text style={[styles.title, { color: colors.primary }]}>where you need them.</Text>
          </View>
          <StatusPill enabled={isEnabled} colors={colors} />
        </View>

        <View style={[styles.heroCard, { backgroundColor: colors.foreground }]}>
          <View style={styles.heroTopline}>
            <View style={[styles.liveIcon, { backgroundColor: colors.accent }]}>
              <Feather name="radio" size={18} color={colors.accentForeground} />
            </View>
            <Text style={[styles.heroLabel, { color: colors.accent }]}>FORWARDING ENGINE</Text>
          </View>
          <Text style={[styles.heroTitle, { color: '#FFFFFF' }]}>
            {isEnabled ? 'Listening for new messages' : 'Ready when you are'}
          </Text>
          <Text style={[styles.heroBody, { color: '#B7C8C3' }]}>
            {isEnabled
              ? 'New incoming SMS will follow your delivery rules.'
              : 'Turn on forwarding to route authorized messages to your destination.'}
          </Text>
          <View style={[styles.heroDivider, { backgroundColor: '#2D4543' }]} />
          <View style={styles.switchRow}>
            <View>
              <Text style={[styles.switchTitle, { color: '#FFFFFF' }]}>Automatic forwarding</Text>
              <Text style={[styles.switchCaption, { color: '#8EA7A1' }]}>
                {isEnabled ? 'Your relay is live' : 'Currently paused'}
              </Text>
            </View>
            <Switch
              accessibilityLabel="Toggle automatic forwarding"
              testID="forwarding-switch"
              value={isEnabled}
              onValueChange={onToggle}
              trackColor={{ false: '#385350', true: colors.accent }}
              thumbColor={isEnabled ? colors.primary : '#D8E2DE'}
              ios_backgroundColor="#385350"
            />
          </View>
        </View>

        <View style={[styles.permissionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <IconCircle name="shield" color={colors.primary} backgroundColor={colors.accent} />
          <View style={styles.permissionCopy}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>SMS access</Text>
            <Text style={[styles.cardCaption, { color: colors.mutedForeground }]}>
              {smsPermissionState === 'granted'
                ? 'Permissions granted on this Android device.'
                : 'Required to receive and send messages automatically.'}
            </Text>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Check SMS permissions"
            testID="sms-permission-button"
            onPress={requestSmsAccess}
            style={({ pressed }) => [
              styles.permissionButton,
              { backgroundColor: smsPermissionState === 'granted' ? colors.accent : colors.foreground, opacity: pressed ? 0.75 : 1 },
            ]}
          >
            <Text style={[styles.permissionButtonText, { color: smsPermissionState === 'granted' ? colors.accentForeground : '#FFFFFF' }]}>
              {smsPermissionState === 'granted' ? 'Granted' : 'Check'}
            </Text>
          </Pressable>
        </View>

        <SectionLabel colors={colors}>DELIVERY DESTINATION</SectionLabel>
        <View style={[styles.destinationCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <IconCircle name="send" color={colors.primary} backgroundColor={colors.accent} />
          <View style={styles.destinationCopy}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Send to another phone</Text>
            <Text style={[styles.cardCaption, { color: colors.mutedForeground }]}>
              Messages stay on-device until they are sent.
            </Text>
          </View>
          <Feather name="chevron-right" size={19} color={colors.mutedForeground} />
        </View>

        <View style={[styles.numberField, { borderColor: isEditingNumber ? colors.primary : colors.border, backgroundColor: colors.card }]}>
          <Feather name="phone" size={18} color={colors.mutedForeground} />
          <TextInput
            accessibilityLabel="Destination phone number"
            testID="destination-number-input"
            style={[styles.numberInput, { color: colors.foreground }]}
            placeholder="+91 98765 43210"
            placeholderTextColor={colors.mutedForeground}
            value={destinationNumber}
            onChangeText={setDestinationNumber}
            onFocus={() => setIsEditingNumber(true)}
            onBlur={() => setIsEditingNumber(false)}
            keyboardType="phone-pad"
            textContentType="telephoneNumber"
          />
          {destinationNumber.length > 0 ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Clear destination phone number"
              onPress={() => setDestinationNumber('')}
              hitSlop={12}
            >
              <Feather name="x-circle" size={18} color={colors.mutedForeground} />
            </Pressable>
          ) : null}
        </View>

        <SectionLabel colors={colors}>FORWARDING RULES</SectionLabel>
        <View style={[styles.rulesCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.ruleHeading}>
            <View>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>What should be forwarded?</Text>
              <Text style={[styles.cardCaption, { color: colors.mutedForeground }]}>Choose the messages that matter.</Text>
            </View>
            <IconCircle name="filter" color={colors.primary} backgroundColor={colors.accent} />
          </View>
          <View style={[styles.segmented, { backgroundColor: colors.muted }]}>
            {([
              ['all', 'All messages'],
              ['otp', 'OTP codes only'],
            ] as const).map(([mode, label]) => {
              const selected = filterMode === mode;
              return (
                <Pressable
                  key={mode}
                  accessibilityRole="button"
                  accessibilityState={{ selected }}
                  testID={`filter-${mode}`}
                  onPress={() => onFilterChange(mode)}
                  style={[
                    styles.segment,
                    selected && { backgroundColor: colors.card, elevation: 2 },
                  ]}
                >
                  <Text style={[styles.segmentText, { color: selected ? colors.foreground : colors.mutedForeground }]}>
                    {label}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <SectionLabel colors={colors}>RECENT ACTIVITY</SectionLabel>
          <Text style={[styles.activityCount, { color: colors.mutedForeground }]}>0 forwarded</Text>
        </View>
        <View style={[styles.emptyCard, { borderColor: colors.border, backgroundColor: colors.card }]}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.muted }]}>
            <Feather name="inbox" size={22} color={colors.mutedForeground} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Nothing forwarded yet</Text>
          <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
            Your delivery history will appear here after the first message is sent.
          </Text>
        </View>

        <View style={[styles.privacyNote, { backgroundColor: colors.accent }]}>
          <Feather name="lock" size={16} color={colors.accentForeground} />
          <Text style={[styles.privacyText, { color: colors.accentForeground }]}>
            Private by design. Relay only runs on this device and can be paused anytime.
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { paddingHorizontal: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 30 },
  brandLockup: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  logo: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  wordmark: { fontSize: 20, fontFamily: 'Inter_700Bold', letterSpacing: -0.6, lineHeight: 21 },
  eyebrow: { fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 1.4, marginTop: 3 },
  headerButton: { width: 40, height: 40, borderRadius: 14, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  greetingRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 19 },
  title: { fontSize: 27, lineHeight: 32, fontFamily: 'Inter_700Bold', letterSpacing: -0.9 },
  statusPill: { flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 99, paddingHorizontal: 9, paddingVertical: 6, marginBottom: 4 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusPillText: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 1 },
  heroCard: { borderRadius: 24, padding: 20, marginBottom: 27 },
  heroTopline: { flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 20 },
  liveIcon: { width: 33, height: 33, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  heroLabel: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 1.2 },
  heroTitle: { fontSize: 23, lineHeight: 29, fontFamily: 'Inter_700Bold', letterSpacing: -0.6, marginBottom: 8 },
  heroBody: { fontSize: 13, lineHeight: 19, fontFamily: 'Inter_400Regular', maxWidth: 280 },
  heroDivider: { height: 1, marginVertical: 18 },
  switchRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  switchTitle: { fontSize: 14, fontFamily: 'Inter_600SemiBold', marginBottom: 4 },
  switchCaption: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  permissionCard: { flexDirection: 'row', alignItems: 'center', gap: 12, borderRadius: 18, borderWidth: 1, padding: 13, marginBottom: 26 },
  permissionCopy: { flex: 1 },
  permissionButton: { borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 },
  permissionButtonText: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 0.2 },
  sectionLabel: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.2, marginBottom: 10 },
  destinationCard: { flexDirection: 'row', alignItems: 'center', gap: 12, borderRadius: 18, borderWidth: 1, padding: 15, marginBottom: 10 },
  iconCircle: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  destinationCopy: { flex: 1 },
  cardTitle: { fontSize: 14, fontFamily: 'Inter_600SemiBold', marginBottom: 4 },
  cardCaption: { fontSize: 12, lineHeight: 17, fontFamily: 'Inter_400Regular' },
  numberField: { height: 55, borderRadius: 16, borderWidth: 1, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 15, gap: 11, marginBottom: 25 },
  numberInput: { flex: 1, fontSize: 15, fontFamily: 'Inter_500Medium', paddingVertical: 0 },
  rulesCard: { borderWidth: 1, borderRadius: 18, padding: 16, marginBottom: 27 },
  ruleHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  segmented: { borderRadius: 12, padding: 4, flexDirection: 'row', gap: 4 },
  segment: { flex: 1, minHeight: 39, borderRadius: 9, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 },
  segmentText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  activityCount: { fontSize: 11, fontFamily: 'Inter_500Medium', marginBottom: 10 },
  emptyCard: { minHeight: 156, borderWidth: 1, borderRadius: 18, alignItems: 'center', justifyContent: 'center', padding: 22, marginBottom: 16 },
  emptyIcon: { width: 46, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginBottom: 11 },
  emptyTitle: { fontSize: 14, fontFamily: 'Inter_600SemiBold', marginBottom: 5 },
  emptyBody: { fontSize: 12, lineHeight: 17, fontFamily: 'Inter_400Regular', textAlign: 'center', maxWidth: 270 },
  privacyNote: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, borderRadius: 14, padding: 13 },
  privacyText: { flex: 1, fontSize: 11, lineHeight: 16, fontFamily: 'Inter_500Medium' },
});